<html>
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
<p><strong>Hi {{$name}}</strong>,</p>

<p>Profile Updation Required</p>
<p>Dear user, we are trying to fill your application so we find your profile incomplete. We need some document to submit on gov websites so kindly upload on your profile.</p>

</div>

</body>
</html>