function SetNotificationAsRead(id_,thisObj){
    thisObj.attr("disabled", true);
    $.ajax({
        type: "GET",
        processData: false,
        contentType: false,
        url: thisObj.data('url'),
        data:  [],// serializes the form's elements.
        success: function (data) {
            if (data.status==1) {                
                $(`#user_notification_${id_}`).removeClass('notification-list--unread');
                thisObj.css('display','none');
            }
        },
        error: function (data) {
            $.each(data.responseJSON.errors, function (key, value) {
                // console.error("error", value);
            });
            btn.attr("disabled", false);
        }
    });
}

function SetNotificationToRead(thisObj){
    $.ajax({
        type: "GET",
        processData: false,
        contentType: false,
        url: thisObj.data('url'),
        data:  [],// serializes the form's elements.
        success: function (data) {
            if (data.status==1) {        
            }
        },
        error: function (data) {
            $.each(data.responseJSON.errors, function (key, value) {
                // console.error("error", value);
            });
        }
    });
}

function GetMoreReadNotification(thisObj){
    $.ajax({
        type: "GET",
        processData: false,
        contentType: false,
        url: thisObj.data('url'),
        data:  {
            offset : thisObj.data('offset'),
            limit : thisObj.data('limit'),
        },// serializes the form's elements.
        success: function (data) {
            if (data.status==1) {        
                if (data.data.length > 0) {
                    console.log("debugging1111...",data.data);
                    AppendNotifications(data.data)
                }
            }
        },
        error: function (data) {
            $.each(data.responseJSON.errors, function (key, value) {
                // console.error("error", value);
            });
        }
    });
}
